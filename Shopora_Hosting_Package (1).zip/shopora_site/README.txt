SHOPORA — MINI E-COMMERCE DEMO

Main website file: index.html

QUICK DEPLOY (Netlify)
1. Sign in to a Netlify account at https://app.netlify.com/ (create a free account if needed).
2. Open https://app.netlify.com/drop
3. Upload this ZIP file or drag the extracted shopora_site folder onto the drop area.
4. Wait for deployment to finish and open the generated *.netlify.app URL.
5. Make sure the site is published/publicly accessible in the site's settings.
6. Keep the Netlify account and site project active. Save the live URL somewhere safe.

IMPORTANT
- The site is a frontend demo only. It does not process real payments, create real accounts, or place real orders.
- Do not enter real passwords or payment details.
- The generated URL is assigned by Netlify; it cannot be known before deployment.
